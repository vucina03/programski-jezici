package rs.ac.singidunum.basketball_application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasketballApplicationTests {

	@Test
	void contextLoads() {
	}

}
